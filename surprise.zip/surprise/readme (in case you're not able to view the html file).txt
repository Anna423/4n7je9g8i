----------------------------------READ THE INSTRUCTIONS CAREFULLY-------------------------------------

Before running the run-me file, please unzip the files and keep them in the same folder.
(Example: Instead of keeping the files in say 'files.zip', create a seperate folder (in this example the folders name is 'files') in whatever location you like.)
Also, please make sure that you have Windows Powershell installed. 
If you're on Windows 7 or later, then it's installed by default.
(Download documentation (if you need it): https://bit.ly/3IUjGiw)
DO NOT rename any of the files present in the folder.

And finally, to actually run the run-me file, right click on it and select "Run with Powershell". After that, you should see the Powershell window.
Now for the run-me file to run properly, press "Y"(capital y) on your keyboard if you see the 'Execution Policy Change' prompt.